package pe.edu.unmsm.upg.banking.customers.application;

public class ShowCustomerErrorResponseDto {
	private String message;

	public ShowCustomerErrorResponseDto()
	{
		this.message = "Error Showing Persona";
	}
	
	public String getMessage() {
		return message;
	}
}