package pe.edu.unmsm.upg.banking.transactions.messages;

import org.axonframework.modelling.command.TargetAggregateIdentifier;

public class MarkMoneyTransferFailedCommand {
	@TargetAggregateIdentifier
	private final String transferId;
	
	public MarkMoneyTransferFailedCommand(String transferId) {
		this.transferId = transferId;
	}

	public String getTransferId() {
		return transferId;
	}
}