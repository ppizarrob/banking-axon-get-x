package pe.edu.unmsm.upg.banking.accounts.query;

import org.axonframework.eventhandling.EventHandler;
import org.springframework.stereotype.Component;

import pe.edu.unmsm.upg.banking.accounts.messages.*;

@Component
public class AccountViewProjection {
	private final AccountViewRepository accountViewRepository;
	
	public AccountViewProjection(AccountViewRepository accountViewRepository) {
        this.accountViewRepository = accountViewRepository;
    }
	
	@EventHandler
    public void handle(AccountOpenedEvent event) {
		AccountView accountView = new AccountView(event.getAccountId(), 0.00, event.getOverdraftLimit());
		accountViewRepository.save(accountView);
    }
	
	@EventHandler
    public void handle(SourceAccountDebitedEvent event) {
		AccountView accountView = accountViewRepository.findOneByAccountId(event.getAccountId());
		accountView.setBalance(accountView.getBalance() - event.getAmount());
		accountViewRepository.save(accountView);
    }
	
	@EventHandler
    public void handle(DestinationAccountCreditedEvent event) {
		AccountView accountView = accountViewRepository.findOneByAccountId(event.getAccountId());
		accountView.setBalance(accountView.getBalance() + event.getAmount());
		accountViewRepository.save(accountView);
    }
}