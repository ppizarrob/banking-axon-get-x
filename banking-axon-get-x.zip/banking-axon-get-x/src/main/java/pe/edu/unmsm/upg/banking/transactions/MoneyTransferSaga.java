package pe.edu.unmsm.upg.banking.transactions;

import org.axonframework.commandhandling.gateway.CommandGateway;
import org.axonframework.modelling.saga.EndSaga;
import org.axonframework.modelling.saga.SagaEventHandler;
import org.axonframework.modelling.saga.StartSaga;
import org.axonframework.spring.stereotype.Saga;

import pe.edu.unmsm.upg.banking.accounts.messages.*;
import pe.edu.unmsm.upg.banking.transactions.messages.*;

import javax.inject.Inject;

@Saga
public class MoneyTransferSaga {
	private String sourceAccountId;
    private String destinationAccountId;
    private double amount;
    
	@Inject
    private transient CommandGateway commandGateway;
	
	@StartSaga
    @SagaEventHandler(associationProperty = "transferId")
    public void handle(MoneyTransferRequestedEvent event) {
		this.sourceAccountId = event.getSourceAccountId();
        this.destinationAccountId = event.getDestinationAccountId();
        this.amount = event.getAmount();
        DebitSourceAccountCommand command = new DebitSourceAccountCommand(
        		event.getSourceAccountId(),
                event.getTransferId(),
                event.getAmount());
        commandGateway.send(command);
	}
	
	@SagaEventHandler(associationProperty = "transferId")
    @EndSaga
    public void handle(SourceAccountNotFoundEvent event) {
        MarkMoneyTransferFailedCommand command = new MarkMoneyTransferFailedCommand(event.getTransferId());
        commandGateway.send(command);
    }
	
	@SagaEventHandler(associationProperty = "transferId")
    @EndSaga
    public void handle(DestinationAccountNotFoundEvent event) {
        ReturnMoneyOfFailedMoneyTransferCommand returnMoneyCommand = 
        		new ReturnMoneyOfFailedMoneyTransferCommand(this.sourceAccountId, event.getTransferId(), this.amount);
        commandGateway.send(returnMoneyCommand);

        MarkMoneyTransferFailedCommand command = new MarkMoneyTransferFailedCommand(
                event.getTransferId());
        commandGateway.send(command);
    }
	
	@SagaEventHandler(associationProperty = "transferId")
    @EndSaga
    public void handle(SourceAccountDebitRejectedEvent event) {
		MarkMoneyTransferFailedCommand command = new MarkMoneyTransferFailedCommand(event.getTransferId());
		commandGateway.send(command);
    }
	
	@SagaEventHandler(associationProperty = "transferId")
    public void on(SourceAccountDebitedEvent event) {
        CreditDestinationAccountCommand command = 
        		new CreditDestinationAccountCommand(destinationAccountId,
                                                    event.getTransferId(),
                                                    event.getAmount());
        commandGateway.send(command);
    }
	
	@EndSaga
    @SagaEventHandler(associationProperty = "transferId")
    public void on(DestinationAccountCreditedEvent event) {
        MarkMoneyTransferCompletedCommand command = new MarkMoneyTransferCompletedCommand(event.getTransferId());
        commandGateway.send(command);
    }
}