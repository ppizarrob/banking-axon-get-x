package pe.edu.unmsm.upg.banking;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BankingAxonApplication {
	public static void main(String[] args) {
		SpringApplication.run(BankingAxonApplication.class, args);
	}
}