package pe.edu.unmsm.upg.banking.customers.application;

public class EditCustomerOkResponseDto {
	private String dni;
	
	public EditCustomerOkResponseDto(String dni)
	{
		this.dni = dni;
	}
	
	public String getDni() {
		return dni;
	}
}