package pe.edu.unmsm.upg.banking.transactions.messages;

public class MoneyTransferFailedEvent {
	private String transferId;
	
	public MoneyTransferFailedEvent(String transferId) {
		this.transferId = transferId;
	}
	
	public String getTransferId() {
		return transferId;
	}
}