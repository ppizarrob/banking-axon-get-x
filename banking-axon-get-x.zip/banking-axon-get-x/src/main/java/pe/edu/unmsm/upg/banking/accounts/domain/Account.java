package pe.edu.unmsm.upg.banking.accounts.domain;

import static org.axonframework.modelling.command.AggregateLifecycle.apply;

import org.axonframework.commandhandling.CommandHandler;
import org.axonframework.eventsourcing.EventSourcingHandler;
import org.axonframework.modelling.command.AggregateIdentifier;
import org.axonframework.spring.stereotype.Aggregate;

import pe.edu.unmsm.upg.banking.accounts.messages.*;

@Aggregate
public class Account {
	@AggregateIdentifier
    private String accountId;
    private double balance;
    private double overdraftLimit;
    @SuppressWarnings("unused")
	private String customerId;
    
    public Account() {
    }
    
    @CommandHandler
    public Account(OpenAccountCommand command) {
        apply(new AccountOpenedEvent(command.getAccountId(), command.getOverdraftLimit(), command.getCustomerId()));
    }
    
    @CommandHandler
    public void handle(EditAccountCommand command) {
        apply(new AccountEditedEvent(command.getAccountId(), command.getOverdraftLimit()));
    }
    
    @CommandHandler
    public void returnMoney(ReturnMoneyOfFailedMoneyTransferCommand command) {
        apply(new MoneyOfFailedMoneyTransferReturnedEvent(command.getAccountId(), command.getAmount(), command.getTransferId()));
    }
    
    @EventSourcingHandler
    protected void handle(AccountOpenedEvent event) {
        this.accountId = event.getAccountId();
        this.balance = 0.0;
        this.overdraftLimit = event.getOverdraftLimit();
        this.customerId = event.getCustomerId();
    }
    
    @EventSourcingHandler
    protected void handle(AccountEditedEvent event) {
        this.overdraftLimit = event.getOverdraftLimit();
    }
    
    @EventSourcingHandler
    public void handle(SourceAccountDebitedEvent event) {
        balance -= event.getAmount();
    }

    @EventSourcingHandler
    public void handle(DestinationAccountCreditedEvent event) {
        balance += event.getAmount();
    }
    
    public void debit(double amount, String transferId) {
        if (amount <= balance + overdraftLimit) {
            apply(new SourceAccountDebitedEvent(accountId, amount, transferId));
        }
        else {
            apply(new SourceAccountDebitRejectedEvent(accountId, transferId));
        }
    }

    public void credit(double amount, String transferId) {
        apply(new DestinationAccountCreditedEvent(accountId, amount, transferId));
    }
}