package pe.edu.unmsm.upg.banking.customers.query;

import java.time.Instant;

import org.axonframework.eventhandling.EventHandler;
import org.axonframework.eventhandling.Timestamp;
import org.springframework.stereotype.Component;

import pe.edu.unmsm.upg.banking.customers.domain.CustomerStatus;
import pe.edu.unmsm.upg.banking.customers.messages.*;

@Component
public class CustomerViewProjection {
	private final CustomerViewRepository customerViewRepository;
	
	public CustomerViewProjection(CustomerViewRepository customerViewRepository) {
        this.customerViewRepository = customerViewRepository;
    }
	
	@EventHandler
    public void handle(CustomerRegisteredEvent event, @Timestamp Instant timestamp) {
		CustomerView customerView = new CustomerView(
			event.getDni(),
			event.getPaterno(),
			event.getMaterno(),
			event.getNombre(),
			event.getDireccion(),
			event.getUbigeo(),
			event.getFechaNacimiento(),
			event.getEmail(),
			event.getTipovinculo(),
			CustomerStatus.ACTIVE.toString(),
			event.getFechaRegistro(),
			event.getFechaModificacion()		
		);
		customerViewRepository.save(customerView);
    }
	
	@EventHandler
    public void handle(CustomerEditedEvent event, @Timestamp Instant timestamp) {
		CustomerView customerView = customerViewRepository.findOneByDni(event.getDni());
		customerView.setDni(event.getDni());
		customerView.setPaterno(event.getPaterno());
		customerView.setMaterno(event.getMaterno());
		customerView.setNombre(event.getNombre());
		customerView.setDireccion(event.getDireccion());
		customerView.setUbigeo(event.getUbigeo());
		customerView.setFechaNacimiento(event.getFechaNacimiento());
		customerView.setEmail(event.getEmail());
		customerView.setTipovinculo(event.getTipovinculo());
		customerView.setEstado(event.getEstado());
		customerView.setFechaRegistro(event.getFechaRegistro());
		customerView.setFechaModificacion(event.getFechaModificacion());
		customerViewRepository.save(customerView);
    }

	@EventHandler
	public void handle(CustomerShowedEvent event, @Timestamp Instant timestamp) {
		CustomerView customerView = customerViewRepository.findOneByDni(event.getDni());
		customerView.setDni(event.getDni());
		customerView.setPaterno(event.getPaterno());
		customerView.setMaterno(event.getMaterno());
		customerView.setNombre(event.getNombre());
		customerView.setDireccion(event.getDireccion());
		customerView.setUbigeo(event.getUbigeo());
		customerView.setFechaNacimiento(event.getFechaNacimiento());
		customerView.setEmail(event.getEmail());
		customerView.setTipovinculo(event.getTipovinculo());
		customerView.setEstado(event.getEstado());
		customerView.setFechaRegistro(event.getFechaRegistro());
		customerView.setFechaModificacion(event.getFechaModificacion());
		customerViewRepository.save(customerView);
	}
}