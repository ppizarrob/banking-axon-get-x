package pe.edu.unmsm.upg.banking.transactions.application.dto;

public class MoneyTransferOkResponseDto {
	private String transferId;
	
	public MoneyTransferOkResponseDto(String transferId)
	{
		this.transferId = transferId;
	}
	
	public String getTransferId() {
		return transferId;
	}
}