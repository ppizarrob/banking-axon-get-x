package pe.edu.unmsm.upg.banking.customers.api;

import java.util.UUID;
import java.util.*;
import java.util.concurrent.CompletableFuture;

import org.axonframework.commandhandling.gateway.CommandGateway;


import org.springframework.web.bind.annotation.*;

import pe.edu.unmsm.upg.banking.customers.messages.*;
import pe.edu.unmsm.upg.banking.customers.application.*;
import pe.edu.unmsm.upg.banking.customers.query.*;

@RestController
@RequestMapping("/customers")
public class CustomerCommandController {
	private final CommandGateway commandGateway;
	private final CustomerViewRepository customerIdRepository;

	public CustomerCommandController(CommandGateway commandGateway, CustomerViewRepository customerIdRepository) {
        this.commandGateway = commandGateway;
		this.customerIdRepository = customerIdRepository;
    }
	
	@PostMapping("")
	public CompletableFuture<Object> register(@RequestBody RegisterCustomerRequestDto registerCustomerRequestDto) {
		// String customerId = UUID.randomUUID().toString(); // Los DNI son los nuevos indices.
		RegisterCustomerCommand registerCustomerCommand = new RegisterCustomerCommand(
			registerCustomerRequestDto.getDni(),
			registerCustomerRequestDto.getPaterno(),
			registerCustomerRequestDto.getMaterno(),
			registerCustomerRequestDto.getNombre(),
			registerCustomerRequestDto.getDireccion(),
			registerCustomerRequestDto.getUbigeo(),
			registerCustomerRequestDto.getFechaNacimiento(),
			registerCustomerRequestDto.getEmail(),
			registerCustomerRequestDto.getTipovinculo(),
			registerCustomerRequestDto.getEstado(),
			registerCustomerRequestDto.getFechaRegistro(),
			registerCustomerRequestDto.getFechaModificacion()
		);
		// Si el dni ya existe entonces Error ya que es indice
		Optional<CustomerView> customerView = customerIdRepository.findByDni(registerCustomerRequestDto.getDni());
		if (customerView.isPresent()) {
			return new RegisterCustomerErrorResponseDto();
		};
				
		CompletableFuture<Object> future = commandGateway.send(registerCustomerCommand);
		CompletableFuture<Object> response = future.handle((ok, ex) -> {
		    if (ex != null) {
		    	ex.printStackTrace();
		        return new RegisterCustomerErrorResponseDto();
		    }
		    return new RegisterCustomerOkResponseDto(
					registerCustomerRequestDto.getDni()
			);
		});
		return response;
	}
	
	@PutMapping("/{dni}")
	public CompletableFuture<Object> edit(
			@PathVariable("dni") String dni,
			@RequestBody EditCustomerRequestDto editCustomerRequestDto) {
		editCustomerRequestDto.setDni(dni);
		
		EditCustomerCommand editCustomerCommand = new EditCustomerCommand(
			registerCustomerRequestDto.getDni(),
			registerCustomerRequestDto.getPaterno(),
			registerCustomerRequestDto.getMaterno(),
			registerCustomerRequestDto.getNombre(),
			registerCustomerRequestDto.getDireccion(),
			registerCustomerRequestDto.getUbigeo(),
			registerCustomerRequestDto.getFechaNacimiento(),
			registerCustomerRequestDto.getEmail(),
			registerCustomerRequestDto.getTipovinculo(),
			registerCustomerRequestDto.getEstado(),
			registerCustomerRequestDto.getFechaRegistro(),
			registerCustomerRequestDto.getFechaModificacion()
			);
		CompletableFuture<Object> future = commandGateway.send(editCustomerCommand);
		CompletableFuture<Object> response = future.handle((ok, ex) -> {
		    if (ex != null) {
		    	ex.printStackTrace();
		        return new EditCustomerErrorResponseDto();
		    }
		    return new EditCustomerOkResponseDto(
		    	dni
			);
		});
		return response;
	}

	@GetMapping("/{customerId}")
	public CompletableFuture<Object> show(
			@PathVariable("dni") String dni,
			@RequestBody ShowCustomerRequestDto showCustomerRequestDto) {
		showCustomerRequestDto.setDni(dni);

		List<CustomerView> customerViewAll = customerIdRepository.findAll();
		Optional<CustomerView> customerView = customerIdRepository.findByDni(dni);
		if (!customerView.isPresent()) {
			return CompletableFuture.supplyAsync(
					() -> {
						// return new ShowCustomerErrorResponseDto();
						return customerViewAll;
					}
			);
		} else
		return CompletableFuture.supplyAsync(
				() -> {

					return new ShowCustomerOkResponseDto(	
							customerView.get().getDni(),
							customerView.get().getPaterno(),
							customerView.get().getMaterno(),
							customerView.get().getNombre(),
							customerView.get().getDireccion(), 
							customerView.get().getUbigeo(), 
							customerView.get().getFechaNacimiento(), 
							customerView.get().getEmail(), 
							customerView.get().getTipovinculo(), 
							customerView.get().getEstado(), 
							customerView.get().getFechaRegistro(), 
							customerView.get().getFechaModificacion()
					);
				}
		);

	}
	
	
	@@DeleteMapping("/{customerId}")
	public CompletableFuture<Object> show(
			@PathVariable("dni") String dni,
			@RequestBody DeleteCustomerRequestDto deleteCustomerRequestDto) {
		deleteCustomerRequestDto.setDni(dni);

		// Verificamos si existe el dni
		Optional<CustomerView> customerView = customerIdRepository.findByDni(dni);
		if (!customerView.isPresent()) {
			return CompletableFuture.supplyAsync(
					() -> {
						return new DeleteCustomerErrorResponseDto();
					}
			);
		};
		
		// Caso exista cambiamos el estado

		DeleteCustomerCommand deleteCustomerCommand = new DeleteCustomerCommand(
				deleteCustomerRequestDto.getDni()// solo necesitamos el dni
			);

		CompletableFuture<Object> future = commandGateway.send(deleteCustomerCommand);
		CompletableFuture<Object> response = future.handle((ok, ex) -> {
		    if (ex != null) {
		    	ex.printStackTrace();
		        return new DeleteCustomerErrorResponseDto();
		    }
		    return new DeleteCustomerOkResponseDto(
		    	dni
			);
		});
		return response;

		

	}
	
}