package pe.edu.unmsm.upg.banking.transactions.messages;

import org.axonframework.modelling.command.TargetAggregateIdentifier;

public class MarkMoneyTransferCompletedCommand {
	@TargetAggregateIdentifier
	private final String transferId;
	
	public MarkMoneyTransferCompletedCommand(String transferId) {
		this.transferId = transferId;
	}

	public String getTransferId() {
		return transferId;
	}
}