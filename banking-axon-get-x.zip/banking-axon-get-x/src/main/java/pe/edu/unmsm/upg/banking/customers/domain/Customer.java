package pe.edu.unmsm.upg.banking.customers.domain;

import static org.axonframework.modelling.command.AggregateLifecycle.apply;

import org.axonframework.commandhandling.CommandHandler;
import org.axonframework.eventsourcing.EventSourcingHandler;
import org.axonframework.modelling.command.AggregateIdentifier;
import org.axonframework.spring.stereotype.Aggregate;

import pe.edu.unmsm.upg.banking.customers.messages.*;

@Aggregate
public class Customer {
	@AggregateIdentifier
	private String dni;
	private String paterno;
	private String materno;
	private String nombre;
	private String direccion;
	private String ubigeo;
	private String fechaNacimiento;
	private String email;
	private String tipovinculo;
	private CustomerStatus estado;
	private String fechaRegistro;
	private String fechaModificacion;

	
	public Customer() {
    }
    
    @CommandHandler
    public Customer(RegisterCustomerCommand command) {
        apply(
        	new CustomerRegisteredEvent(		
				command.getDni(),
				command.getPaterno(),
				command.getMaterno(),
				command.getNombre(),
				command.getDireccion(),
				command.getUbigeo(),
				command.getFechaNacimiento(),
				command.getEmail(),
				command.getTipovinculo(),
				command.getEstado(),
				command.getFechaRegistro(),
				command.getFechaModificacion()
        	)
        );
    }
    
    @CommandHandler
    public void handle(EditCustomerCommand command) {
        apply(
        	new CustomerEditedEvent(
				command.getDni(),
				command.getPaterno(),
				command.getMaterno(),
				command.getNombre(),
				command.getDireccion(),
				command.getUbigeo(),
				command.getFechaNacimiento(),
				command.getEmail(),
				command.getTipovinculo(),
				command.getEstado(),
				command.getFechaRegistro(),
				command.getFechaModificacion()
        	)
        );
    }

    @CommandHandler
    public void handle(ShowCustomerCommand command) {
        apply(
                new CustomerEditedEvent(
				command.getDni(),
				command.getPaterno(),
				command.getMaterno(),
				command.getNombre(),
				command.getDireccion(),
				command.getUbigeo(),
				command.getFechaNacimiento(),
				command.getEmail(),
				command.getTipovinculo(),
				command.getEstado(),
				command.getFechaRegistro(),
				command.getFechaModificacion()
				)
        );
    }

    @EventSourcingHandler
    protected void handle(CustomerRegisteredEvent event) {

        //this.status = CustomerStatus.ACTIVE;
		this.dni = event.getDni();
		this.paterno = event.getPaterno();
		this.materno = event.getMaterno();
		this.nombre = event.getNombre();
		this.direccion = event.getDireccion();
		this.ubigeo = event.getUbigeo();
		this.fechaNacimiento = event.getFechaNacimiento();
		this.email = event.getEmail();
		this.tipovinculo = event.getTipovinculo();
		this.estado = CustomerStatus.ACTIVE;
		this.fechaRegistro = event.getFechaRegistro();
		this.fechaModificacion = event.getFechaModificacion();
			
    }
    
    @EventSourcingHandler
    protected void handle(CustomerEditedEvent event) {
		this.dni = event.getDni();
		this.paterno = event.getPaterno();
		this.materno = event.getMaterno();
		this.nombre = event.getNombre();
		this.direccion = event.getDireccion();
		this.ubigeo = event.getUbigeo();
		this.fechaNacimiento = event.getFechaNacimiento();
		this.email = event.getEmail();
		this.tipovinculo = event.getTipovinculo();
		this.estado = CustomerStatus.ACTIVE;        // solo se puede cambiar el estado mediante @deletemapping
		this.fechaRegistro = event.getFechaRegistro();
		this.fechaModificacion = event.getFechaModificacion();
    }

    protected void handle(CustomerShowedEvent event) {
		this.dni = event.getDni();
		this.paterno = event.getPaterno();
		this.materno = event.getMaterno();
		this.nombre = event.getNombre();
		this.direccion = event.getDireccion();
		this.ubigeo = event.getUbigeo();
		this.fechaNacimiento = event.getFechaNacimiento();
		this.email = event.getEmail();
		this.tipovinculo = event.getTipovinculo();
		this.estado = CustomerStatus.ACTIVE;
		this.fechaRegistro = event.getFechaRegistro();
		this.fechaModificacion = event.getFechaModificacion();
    }

}