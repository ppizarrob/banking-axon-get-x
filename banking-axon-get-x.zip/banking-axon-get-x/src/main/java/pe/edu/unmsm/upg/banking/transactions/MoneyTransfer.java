package pe.edu.unmsm.upg.banking.transactions;

import static org.axonframework.modelling.command.AggregateLifecycle.apply;

import org.axonframework.commandhandling.CommandHandler;
import org.axonframework.eventsourcing.EventSourcingHandler;
import org.axonframework.modelling.command.AggregateIdentifier;
import org.axonframework.spring.stereotype.Aggregate;

import pe.edu.unmsm.upg.banking.transactions.messages.MarkMoneyTransferCompletedCommand;
import pe.edu.unmsm.upg.banking.transactions.messages.MarkMoneyTransferFailedCommand;
import pe.edu.unmsm.upg.banking.transactions.messages.MoneyTransferCompletedEvent;
import pe.edu.unmsm.upg.banking.transactions.messages.MoneyTransferFailedEvent;
import pe.edu.unmsm.upg.banking.transactions.messages.MoneyTransferRequestedEvent;
import pe.edu.unmsm.upg.banking.transactions.messages.RequestMoneyTransferCommand;

@Aggregate
public class MoneyTransfer {
	@AggregateIdentifier
    private String transferId;
	private String sourceAccountId;
    private String destinationAccountId;
    private double amount;
    private Status status;
    
    protected MoneyTransfer() {
    }
	
	@CommandHandler
    public MoneyTransfer(RequestMoneyTransferCommand command) {
        apply(
        	new MoneyTransferRequestedEvent(
        		command.getTransferId(), 
        		command.getSourceAccountId(),
        		command.getDestinationAccountId(),
        		command.getAmount()
        	)
        );
    }
	
	@CommandHandler
    public void handle(MarkMoneyTransferCompletedCommand command) {
        apply(new MoneyTransferCompletedEvent(command.getTransferId()));
    }
	
	@CommandHandler
    public void handle(MarkMoneyTransferFailedCommand command) {
        apply(new MoneyTransferFailedEvent(command.getTransferId()));
    }
	
	@EventSourcingHandler
    protected void handle(MoneyTransferRequestedEvent event) {
        this.transferId = event.getTransferId();
        this.sourceAccountId = event.getSourceAccountId();
        this.destinationAccountId = event.getDestinationAccountId();
        this.amount = event.getAmount();
        this.status = Status.STARTED;
    }
	
	@EventSourcingHandler
    public void handle(MoneyTransferCompletedEvent event) {
        this.status = Status.COMPLETED;
    }
	
	@EventSourcingHandler
    public void handle(MoneyTransferFailedEvent event) {
        this.status = Status.FAILED;
    }
	
	private enum Status {
        STARTED,
        FAILED,
        COMPLETED
    }
}