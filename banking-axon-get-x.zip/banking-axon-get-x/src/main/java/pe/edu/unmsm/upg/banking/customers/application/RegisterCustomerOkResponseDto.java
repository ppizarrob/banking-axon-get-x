package pe.edu.unmsm.upg.banking.customers.application;

public class RegisterCustomerOkResponseDto {
	private String dni;
	
	public RegisterCustomerOkResponseDto(String dni)
	{
		this.dni = dni;
	}

	public String getDni() {
		return dni;
	}
}