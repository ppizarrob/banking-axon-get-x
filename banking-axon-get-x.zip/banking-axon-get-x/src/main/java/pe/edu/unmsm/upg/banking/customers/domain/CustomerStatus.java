package pe.edu.unmsm.upg.banking.customers.domain;

public enum CustomerStatus {
	ACTIVE,
    INACTIVE
}