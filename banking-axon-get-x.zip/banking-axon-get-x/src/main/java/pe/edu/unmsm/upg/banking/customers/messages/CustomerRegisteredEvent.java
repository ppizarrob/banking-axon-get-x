package pe.edu.unmsm.upg.banking.customers.messages;

public class CustomerRegisteredEvent {
	private String dni;
	private String paterno;
	private String materno;
	private String nombre;
	private String direccion;
	private String ubigeo;
	private String fechaNacimiento;
	private String email;
	private String tipovinculo;
	private String estado;
	private String fechaRegistro;
	private String fechaModificacion;


    public CustomerRegisteredEvent(String dni, String paterno, String materno, 
								String nombre, String direccion, String ubigeo, 
								String fechaNacimiento, String email, String tipovinculo, 
								String estado, String fechaRegistro, String fechaModificacion) {
		this.dni = dni;
		this.paterno = paterno;
		this.materno = materno;
		this.nombre = nombre;
		this.direccion = direccion;
		this.ubigeo = ubigeo;
		this.fechaNacimiento = fechaNacimiento;
		this.email = email;
		this.tipovinculo = tipovinculo;
		this.estado = estado;
		this.fechaRegistro = fechaRegistro;
		this.fechaModificacion = fechaModificacion;
	}

	public String getDni() { return dni; }
	public String getPaterno() { return paterno; }
	public String getMaterno() { return materno; }
	public String getNombre() { return nombre; }
	public String getDireccion() { return direccion; }
	public String getUbigeo() { return ubigeo; }
	public String getFechaNacimiento() { return fechaNacimiento; }
	public String getEmail() { return email; }
	public String getTipovinculo() { return tipovinculo; }
	public String getEstado() { return estado; }
	public String getFechaRegistro() { return fechaRegistro; }
	public String getFechaModificacion() { return fechaModificacion; }
	

}