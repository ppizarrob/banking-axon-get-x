package pe.edu.unmsm.upg.banking.accounts.messages;

public class DestinationAccountNotFoundEvent {
	private String accountId;
	private String transferId;
    
    public DestinationAccountNotFoundEvent(String accountId, String transferId) {
		this.accountId = accountId;
		this.transferId = transferId;
	}

	public String getAccountId() {
		return accountId;
	}

	public String getTransferId() {
		return transferId;
	}
}