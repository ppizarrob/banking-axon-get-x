package pe.edu.unmsm.upg.banking.accounts.messages;

public class SourceAccountDebitedEvent {
	private String accountId;
	private double amount;
	private String transferId;
    
    public SourceAccountDebitedEvent(String accountId, double amount, String transferId) {
		this.accountId = accountId;
		this.amount = amount;
		this.transferId = transferId;
	}

	public String getAccountId() {
		return accountId;
	}

	public double getAmount() {
		return amount;
	}

	public String getTransferId() {
		return transferId;
	}
}