package pe.edu.unmsm.upg.banking.transactions.api;

import java.util.*;
import java.util.concurrent.CompletableFuture;

import org.axonframework.commandhandling.gateway.CommandGateway;
import org.springframework.web.bind.annotation.*;
import org.springframework.validation.annotation.Validated;

import pe.edu.unmsm.upg.banking.transactions.application.dto.*;
import pe.edu.unmsm.upg.banking.transactions.messages.*;

@RestController
@RequestMapping("/transfers")
public class MoneyTransferCommandController {
	private final CommandGateway commandGateway;
	
	public MoneyTransferCommandController(CommandGateway commandGateway) {
        this.commandGateway = commandGateway;
    }
	
	@PostMapping("")
	public CompletableFuture<Object> transfer(@Validated @RequestBody MoneyTransferRequestDto moneyTransferRequestDto) {
		String transferId = UUID.randomUUID().toString();
		RequestMoneyTransferCommand command = new RequestMoneyTransferCommand(
			transferId,
			moneyTransferRequestDto.getSourceAccountId(),
			moneyTransferRequestDto.getDestinationAccountId(),
			moneyTransferRequestDto.getAmount()
		);
		CompletableFuture<Object> future = commandGateway.send(command);
		CompletableFuture<Object> response = future.handle((ok, ex) -> {
		    if (ex != null) {
		    	ex.printStackTrace();
		        return new MoneyTransferErrorResponseDto();
		    }
		    return new MoneyTransferOkResponseDto(
		    		transferId
			);
		});
		return response;
	}
}