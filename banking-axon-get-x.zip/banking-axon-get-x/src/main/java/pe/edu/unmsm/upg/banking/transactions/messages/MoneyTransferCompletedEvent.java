package pe.edu.unmsm.upg.banking.transactions.messages;

public class MoneyTransferCompletedEvent {
	private String transferId;
	
	public MoneyTransferCompletedEvent(String transferId) {
		this.transferId = transferId;
	}
	
	public String getTransferId() {
		return transferId;
	}
}