package pe.edu.unmsm.upg.banking.transactions.messages;

import org.axonframework.modelling.command.TargetAggregateIdentifier;

public class RequestMoneyTransferCommand {
	@TargetAggregateIdentifier
	private final String transferId;
	private final String sourceAccountId;
	private final String destinationAccountId;
	private final double amount;
	
	public RequestMoneyTransferCommand(String transferId, String sourceAccountId, String destinationAccountId, double amount) {
		this.transferId = transferId;
		this.sourceAccountId = sourceAccountId;
		this.destinationAccountId = destinationAccountId;
		this.amount = amount;
	}

	public String getTransferId() {
		return transferId;
	}

	public String getSourceAccountId() {
		return sourceAccountId;
	}

	public String getDestinationAccountId() {
		return destinationAccountId;
	}

	public double getAmount() {
		return amount;
	}
}